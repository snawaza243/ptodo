<?php

function sanitize_input($data)
{
    // Sanitize data to prevent XSS and SQL injection
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

function connect_db()
{
    // Use your secure config values and PDO connection (example from config.php)
    try {
        $conn = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_DATABASE, DB_USERNAME, DB_PASSWORD);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $conn;
    } catch (PDOException $e) {
        echo "Database connection failed: " . $e->getMessage();
        exit();
    }
}

function get_user_by_username($username, $conn)
{
    // Securely retrieve user data using prepared statements
    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->bindParam(1, $username, PDO::PARAM_STR);
    $stmt->execute();
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function check_existing_user($username, $email, $conn)
{
    // Check if username or email already exists
    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ? OR email = ?");
    $stmt->bindParam(1, $username, PDO::PARAM_STR);
    $stmt->bindParam(2, $email, PDO::PARAM_STR);
    $stmt->execute();
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function create_task($user_id, $title, $description, $due_date, $conn)
{
    // Securely insert task data with prepared statements
    $stmt = $conn->prepare("INSERT INTO tasks (user_id, title, description, due_date) VALUES (?, ?, ?, ?)");
    $stmt->bindParam(1, $user_id, PDO::PARAM_INT);
    $stmt->bindParam(2, $title, PDO::PARAM_STR);
    $stmt->bindParam(3, $description, PDO::PARAM_STR);
    $stmt->bindParam(4, $due_date, PDO::PARAM_STR);
    return $stmt->execute();
}

function read_tasks($user_id, $conn)
{
    // Securely retrieve tasks specific to the user using WHERE clause
    $stmt = $conn->prepare("SELECT * FROM tasks WHERE user_id = ?");
    $stmt->bindParam(1, $user_id, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function update_task($task_id, $title, $description, $due_date, $conn)
{
    // Securely update task data with prepared statements, restricting based on ownership
    $stmt = $conn->prepare("UPDATE tasks SET title = ?, description = ?, due_date = ? WHERE task_id = ? AND user_id = ?");
    $stmt->bindParam(1, $title, PDO::PARAM_STR);
    $stmt->bindParam(2, $description, PDO::PARAM_STR);
    $stmt->bindParam(3, $due_date, PDO::PARAM_STR);
    $stmt->bindParam(4, $task_id, PDO::PARAM_INT);
    $stmt->bindParam(5, $user_id, PDO::PARAM_INT); // Add user_id check
    return $stmt->execute();
}

function delete_task($task_id, $user_id, $conn)
{
    // Securely delete task, restricting based on ownership
    $stmt = $conn->prepare("DELETE FROM tasks WHERE task_id = ? AND user_id = ?");
    $stmt->bindParam(1, $task_id, PDO::PARAM_INT);
    $stmt->bindParam(2, $user_id, PDO::PARAM_INT);
    return $stmt->execute();
}

// Add more functions as needed...
