<?php

// Use a library like dotenv to load credentials from a separate file
// require_once('vendor/autoload.php');
// $dotenv = new Dotenv\Dotenv(__DIR__);
// $dotenv->load();

// Define database connection details
define('DB_HOST', 'localhost'); 
define('DB_USERNAME', 'root'); 
define('DB_PASSWORD', 'mysql1234'); 
define('DB_DATABASE', 'todophp'); 


// Create database connection (using PDO is recommended)
try {
    $conn = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_DATABASE, DB_USERNAME, DB_PASSWORD);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
    exit();
}

// Other configuration settings (if needed)
